package gm.empleados_igac;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpleadosIgacApplicationTests {

	@Test
	void contextLoads() {
	}

}
